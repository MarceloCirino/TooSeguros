﻿using TooSeguros.TesteMarceCirino.Domain.Arguments;
using TooSeguros.TesteMarceCirino.Domain.Arguments.Conta;
using TooSeguros.TesteMarceCirino.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace TooSeguros.TesteMarceCirino.Domain.Interfaces.Service
{
    public interface IOperacaoService
    {
        Task<OperacaoArgument> RealizaTransacao(OperacaoArgument argument);
    }
}
