﻿using TooSeguros.TesteMarceCirino.Domain.Arguments;
using TooSeguros.TesteMarceCirino.Domain.Arguments.Conta;
using TooSeguros.TesteMarceCirino.Domain.Enums;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace TooSeguros.TesteMarceCirino.Domain.Interfaces.Service
{
    public interface ILancamentoService
    {
        Task<OperacaoArgument> EfetuaLancamento(ContaArgument contaOrigem, ContaArgument contaDestino, TipoOperacao tipoOperacao, decimal valor);
    }
}
