﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TooSeguros.TesteMarceCirino.Domain.Entities.Base
{
    public abstract class EntityBase
    {
        public EntityBase()
        {
        }

    }
}
