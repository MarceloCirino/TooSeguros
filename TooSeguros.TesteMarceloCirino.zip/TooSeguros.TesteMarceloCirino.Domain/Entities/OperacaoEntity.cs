﻿using TooSeguros.TesteMarceCirino.Domain.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace TooSeguros.TesteMarceCirino.Domain.Entities
{
    public class Operacao
    {
        public Conta ContaOrigem { get; set; }

        public Conta ContaDestino { get; set; }

        public TipoOperacao Tipo { get; set; }

        public DateTime DataRegistroOperacao { get; set; }
    }
}
