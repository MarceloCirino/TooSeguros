﻿using TooSeguros.TesteMarceCirino.Domain.Entities;
using TooSeguros.TesteMarceCirino.Domain.Interfaces.Repository;
using System.Threading.Tasks;

namespace TooSeguros.TesteMarceCirino.Infra
{
    public class LancamentoRepository : ILancamentoRepository
    {
        public async Task RegistraLancamento(Operacao operacao)
        {
            //persiste dados do lancamento no banco de dados;
        }
    }
}
